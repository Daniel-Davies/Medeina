
- New API? https://www.gbif.org/developer/species
- MultiThread requests? Is it possible because of the GIL?
- Percentage-wise reqs when indexing
- to_graph_original()
- to_list_original(), to_graph_original(),to_matrix_original()

# Required

- Exceptions for rows and cols in the dictionary // 'nameDepth'
- Metadata in the matrices // 
- Including dates //  use pandas native lib
- Including locations //

- Dynamically decide the API politeness
- Object sensing that underlying structure was changed